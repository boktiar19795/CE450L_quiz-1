import RPi.GPIO as GPIO
import time

# Define GPIO pins
red_pin = 23
green_pin = 24
blue_pin = 16

# Define Morse code dictionary for each character
morse_code = {
    'T': ['-'],
    'E': ['.'],
    'S': ['.', '.', '.'],
    'T': ['-'],
    '1': ['.', '-', '-', '-', '-'],
    '2': ['.', '.', '-', '-', '-'],
    '3': ['.', '.', '.', '-', '-']
}

# Set up GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(red_pin, GPIO.OUT)
GPIO.setup(green_pin, GPIO.OUT)
GPIO.setup(blue_pin, GPIO.OUT)

# Set initial LED states
GPIO.output(red_pin, GPIO.LOW)
GPIO.output(green_pin, GPIO.LOW)
GPIO.output(blue_pin, GPIO.LOW)

# Define dot, dish, and character intervals
dot_interval = 0.2  # Time in seconds
dish_interval = 2 * dot_interval
char_interval = 2 * dish_interval

def send_morse_code(code):
    for symbol in code:
        if symbol == '.':
            GPIO.output(red_pin, GPIO.HIGH)  # Red LED on
            time.sleep(dot_interval)
            GPIO.output(red_pin, GPIO.LOW)  # Red LED off
        elif symbol == '-':
            GPIO.output(blue_pin, GPIO.HIGH)  # Blue LED on
            time.sleep(dish_interval)
            GPIO.output(blue_pin, GPIO.LOW)  # Blue LED off
        time.sleep(dot_interval)  # Pause between symbols

def send_message(message):
    for char in message:
        char = char.upper()
        if char == ' ':
            time.sleep(char_interval)  # Pause between words
        elif char in morse_code:
            code = morse_code[char]
            send_morse_code(code)
            time.sleep(max(char_interval - (len(code) * dot_interval), 0))  # Ensure non-negative sleep length

try:
    while True:
        send_message("TEST123")
        time.sleep(char_interval)  # Pause between message repetitions

except KeyboardInterrupt:
    # Clean up GPIO pins
    GPIO.output(red_pin, GPIO.LOW)
    GPIO.output(green_pin, GPIO.LOW)
    GPIO.output(blue_pin, GPIO.LOW)
    GPIO.cleanup()
